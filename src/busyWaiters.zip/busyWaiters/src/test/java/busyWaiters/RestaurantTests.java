package busyWaiters;


public class RestaurantTests {

}
