package Ex01_WorkingWithAbstraction.P05_JediGalaxy;

public class Star {
    int value;

    public Star(int value) {
        this.value = value;
    }

    public int getValue() {
        return value;
    }
}
